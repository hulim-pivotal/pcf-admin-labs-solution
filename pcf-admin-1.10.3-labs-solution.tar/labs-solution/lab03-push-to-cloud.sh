#!/bin/bash -v
################################### lab03-push-to-cloud.sh
# do this lab on your laptop or Ubuntu Jumpbox and target instructor's PCF instance
echo $ENV_PWD | sudo -S echo

if ! type cf >/dev/null; then
  wget -q -O - https://packages.cloudfoundry.org/debian/cli.cloudfoundry.org.key | sudo apt-key add -
  echo "deb http://packages.cloudfoundry.org/debian stable main" | sudo tee /etc/apt/sources.list.d/cloudfoundry-cli.list
  sudo apt-get update
  sudo apt-get install cf-cli
fi

cf login -a api.run.haas-$INSTRUCTOR_NN.pez.pivotal.io -u $YOUR_USERID -p password --skip-ssl-validation

wget https://github.com/pivotal-education/pcf-hello-world-sample-apps-code/releases/download/0.0.1/pcf-hello-world-sample-apps-0.0.1.zip
unzip -o pcf-hello-world-sample-apps-0.0.1.zip -d pcf-hello-world-sample-apps-0.0.1/
rm pcf-hello-world-sample-apps-0.0.1.zip

cd pcf-hello-world-sample-apps-0.0.1/node/
cf push node-app -m 128M -n node-app-$YOUR_INITIALS
curl node-app-$YOUR_INITIALS.cfapps.haas-$INSTRUCTOR_NN.pez.pivotal.io

cd ../php/
cf push php-app -m 128M -n php-app-$YOUR_INITIALS
curl php-app-$YOUR_INITIALS.cfapps.haas-$INSTRUCTOR_NN.pez.pivotal.io

cd ../python/
cf push python-app -m 128M -n python-app-$YOUR_INITIALS
curl python-app-$YOUR_INITIALS.cfapps.haas-$INSTRUCTOR_NN.pez.pivotal.io

cd ../ruby/
cf push ruby-app -m 128M -n ruby-app-$YOUR_INITIALS
curl ruby-app-$YOUR_INITIALS.cfapps.haas-$INSTRUCTOR_NN.pez.pivotal.io
cd ../..

#cf stop node-app
#cf stop php-app
#cf stop python-app
#cf stop ruby-app
