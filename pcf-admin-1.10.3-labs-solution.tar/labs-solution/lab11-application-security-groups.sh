#!/bin/bash -v
################################### lab11-application-security-groups.sh
# do this lab on your Ubuntu Jumpbox and target your own PCF instance

cf login -a api.run.haas-$NN.pez.pivotal.io -u admin -p $UAA_ADMIN_PWD -o $YOUR_INITIALS-org -s dev --skip-ssl-validation

cf security-groups
cf security-group default_security_group
cf staging-security-groups
cf running-security-groups
cf unbind-running-security-group default_security_group

# the logs will show mysql Communications link failure
# cf logs attendee-service | grep mysql
# cf restart attendee-service

sed "s/\$MYSQL_PROXY_IP/$MYSQL_PROXY_IP/g" templates/asg.json > asg.json

cf create-security-group mysql-$YOUR_INITIALS asg.json

cf bind-security-group mysql-$YOUR_INITIALS $YOUR_INITIALS-org dev

#cf logs attendee-service | grep mysql
#cf restart attendee-service
