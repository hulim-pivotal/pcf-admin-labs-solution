#!/bin/bash -v
################################### lab02-install-elastic-runtime-with-ops-manager.sh
# do this lab using Ops Manager console
