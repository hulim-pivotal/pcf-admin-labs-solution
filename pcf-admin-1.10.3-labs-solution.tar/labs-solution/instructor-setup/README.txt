##################### setup instructor PCF environment #####################

######### install PCF/MySQL/JMXBridge tiles

- remote desktop into Windows Jumpbox

- open web browser to https://opsmgr.haas-$NN.pez.pivotal.io/
- OpsMgr > Ops Manager Director > Director Config > Enable VM Resurrector Plugin
- OpsMgr > Elastic Runtime tile > Resource Config > Diego Cell > 5

- OpsMgr > Import a Product > student-files/p-mysql-[older-version].pivotal > +

- OpsMgr > MySQL tile > AZ and Network Assignments > Network > vmnetwork
                      > Advanced Options > E-mail address > student@example.com
                      > Configure Backups > Disable Backups
                      > Resource Config > Backup Prepare Node instances > 0
                      > Stemcell > Import Stemcell > bosh-stemcell-[required-version].tgz

- OpsMgr > Import a Product > student-files/p-metrics-[version].pivotal > +

- OpsMgr > JMX Bridge tile > AZ and Network Assignments > Network > vmnetwork
                           > JMX Provider > JMX Provider credentials > admin / metrics
                           > Resource Config > OpenTSDB Firehose Nozzle > 1

- OpsMgr > Apply Changes (wait 2hrs for completion)


######### create user account for all students on instructor's PCF instance

- scp labs-solution.tar ubuntu@opsmgr.haas-$NN.pez.pivotal.io:~
- ssh ubuntu@opsmgr.haas-$NN.pez.pivotal.io
- ssh pivotal@10.193.$OCTET.5
- scp ubuntu@opsmgr.haas-$NN.pez.pivotal.io:~/labs-solution.tar .
- tar xvf labs-solution.tar
- edit labs-solution/set-env.sh by filling in variables NN, ENV_PWD, UAA_ADMIN_PWD
- cd labs-solution/instructor-setup
- edit class-participant-emails.txt with students email & unique initials e.g. "tomcruise@movie.net, tc"
- ./create-users.sh  (this script requires bash version 4)


######### setup labs solution for demo/reference

- cd ~/labs-solution
- edit labs-solution/set-env.sh by filling in all variables
- . ./set-env.sh
- ./run-all-labs.sh  (optional)
- ./labNN-xxx.sh     (run individual lab)
