##################### setup instructor PCF environment #####################

######### install PCF/MySQL/JMXBridge tiles

- remote desktop into Windows Jumpbox

- open web browser to https://opsmgr.haas-$NN.pez.pivotal.io/
- OpsMgr > Ops Manager Director > Director Config > Enable VM Resurrector Plugin
- OpsMgr > Elastic Runtime tile > Resource Config > Diego Cell > 3
  (for instructor & students to have same IP suffix for MySQL/etc, set #Cells to 3 same as students)

- OpsMgr > Import a Product > student-files/p-mysql-[older-version].pivotal > +

- OpsMgr > MySQL tile > AZ and Network Assignments > Network > vmnetwork
                      > Advanced Options > E-mail address > student@example.com
                      > Backups > Disable Backups (default)
                      > Resource Config > Backup Prepare Node instances > 0 (default)
                      > Stemcell > Import Stemcell > bosh-stemcell-[required-version].tgz

- OpsMgr > Import a Product > student-files/p-metrics-[version].pivotal > +

- OpsMgr > JMX Bridge tile > AZ and Network Assignments > Network > vmnetwork
                           > JMX Provider > JMX Provider credentials > admin / metrics
                           > Resource Config > OpenTSDB Firehose Nozzle > 1 (default)

- OpsMgr > Apply Changes (wait 2hrs for completion)


######### create user account for all students on instructor's PCF instance

- ssh ubuntu@opsmgr.haas-$NN.pez.pivotal.io
- ssh pivotal@10.193.$OCTET.5
- wget --user pivotal --password makeitwork http://edu.cfapps.io/pcf-admin-1.10.3-labs-solution.tar
- tar xvf pcf-admin-1.10.3-labs-solution.tar
- edit labs-solution/set-env.sh by filling in variables NN, ENV_PWD, UAA_ADMIN_PWD
- cd labs-solution/instructor-setup
- edit class-participant-emails.txt with students email & unique initials e.g. "tomcruise@movie.net, tc"
- ./create-users.sh


######### setup labs solution for demo/reference

- cd ~/labs-solution
- edit labs-solution/set-env.sh by filling in all variables
- . ./set-env.sh
- ./run-all-labs.sh  (optional, wait 1hr for completion)
- ./labNN-xxx.sh     (run individual lab)

setup labs manually:
- disable all Errands on all tiles
- lab08-system-log-draining.sh:
  - OpsMgr > Elastic Runtime tile > System Logging > input PaperTrail host & port & TCP
- lab09-monitoring.sh:
  - OpsMgr > JMX Bridge tile > Status > copy JMX Provider IP address
  - OpsMgr > Ops Manager Director > Director Config > Metrics IP Address > paste JMX Provider IP address
  - OpsMgr > Apply Changes (wait 30min for completion)
  - Setup Datadog nozzle on 10.193.$OCTET.4 (optional since lab15 already created a dashboard)
      sudo /etc/init.d/datadog-agent start
      curl -o datadog-dashboard-gen https://s3.amazonaws.com/pivotal-cloud-foundry-administrator/datadog-dashboard-gen
      chmod +x datadog-dashboard-gen
      ./datadog-dashboard-gen -opsman_user=OPSMAN-USER -opsman_password=OPSMAN-PASSWORD  -opsman_ip=OPSMAN-IP -uaa_domain=UAA-DOMAIN -ddapikey=DATADOG-API-KEY -ddappkey=DATADOG-APP-KEY -use_ops_metrics
      sudo /etc/init.d/datadog-agent stop
