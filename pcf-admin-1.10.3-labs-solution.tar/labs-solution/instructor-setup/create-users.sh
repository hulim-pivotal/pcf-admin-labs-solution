#!/usr/bin/env bash -v
#
# This script requires bash 4! Upgrade!
#
# This script takes in a list of emails (newline seperated) and builds out cf orgs and users.
# It is assumed that the email takes the form of first_last or first.last. We will create an
# org named fl-org where f is the first initial and l is the last initial. If we encounter
# 1 duplicate we will append 1 to the org name. If we encounter two duplicates you're in trouble!
# This script creates org_summary.txt which is helpful for orienting students about where they should go.
#
# Note:
# - 'development' space is changed to 'dev' so that instructor can run all labs without switching spaces.
# - setup env variables NN, ENV_PWD, UAA_ADMIN_PWD in 'set-env.sh' before running this script
# - specify unique initials for students in class-participant-emails.txt e.g. tomcruise@movie.net, tc (optional but recommended)

. ../set-env.sh &>/dev/null

if ! type cf >/dev/null; then
  echo $ENV_PWD | sudo -S echo
  wget -q -O - https://packages.cloudfoundry.org/debian/cli.cloudfoundry.org.key | sudo apt-key add -
  echo "deb http://packages.cloudfoundry.org/debian stable main" | sudo tee /etc/apt/sources.list.d/cloudfoundry-cli.list
  sudo apt-get update
  sudo apt-get install cf-cli
fi

cf login -a api.run.haas-$NN.pez.pivotal.io -u admin -p $UAA_ADMIN_PWD -o system -s system  --skip-ssl-validation

declare -A orgs

echo `date` > org_summary.txt

for line in `sed '/ /s///g' class-participant-emails.txt` ; do

    email=`echo $line | cut -d',' -f1`
    org=`echo $line | cut -d',' -f2`-org

    if [[ $line != *","* ]]; then
      org=`echo $email | tr '_.' "\n" | egrep -v com | colrm 2 | tr -d "\n" && echo -org`
    fi

    if [[ ${orgs[$org]} -gt 0 ]]; then
      orgs[$org]=$((${orgs[$org]}+1))
      org=$org${orgs[$org]}
    else
      orgs[$org]=1
    fi

    echo "INFO: Setting up $org: for $email"

    cf create-org $org
    cf create-space dev -o $org

    cf create-user $email password
    cf set-space-role $email $org dev SpaceDeveloper
done
