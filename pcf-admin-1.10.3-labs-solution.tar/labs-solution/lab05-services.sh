#!/bin/bash -v
################################### lab05-services.sh
# student: do this lab on your laptop and target instructor's PCF instance
# instructor: may run this on your Ubuntu jumpbox since it is in same network segment as your OpsMgr

cf login -a api.run.haas-$INSTRUCTOR_NN.pez.pivotal.io -u $YOUR_USERID -p password --skip-ssl-validation

wget https://github.com/pivotal-education/pcf-attendee-service-code/releases/download/0.0.1/attendee-service-0.0.1-SNAPSHOT.jar

mkdir attendee-service
mv attendee-service-0.0.1-SNAPSHOT.jar attendee-service/
cd attendee-service/

# this will fail bcos mysql not setup yet
cf push attendee-service -p ./attendee-service-0.0.1-SNAPSHOT.jar -m 512M -n attendee-service-$YOUR_INITIALS --no-start

cf create-service p-mysql 100mb attendee-mysql
cf bind-service attendee-service attendee-mysql
cf restart attendee-service

curl http://attendee-service-$YOUR_INITIALS.cfapps.haas-$INSTRUCTOR_NN.pez.pivotal.io

cf create-user-provided-service attendee-service -p uri <<< http://attendee-service-$YOUR_INITIALS.cfapps.haas-$INSTRUCTOR_NN.pez.pivotal.io/attendees
cf bind-service articulate attendee-service
cf restart articulate
cf env articulate
cd ..
