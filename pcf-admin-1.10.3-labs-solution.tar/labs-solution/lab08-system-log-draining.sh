#!/bin/bash -v
################################### lab08-system-log-draining.sh
# do this lab using Ops Manager and Papertrail consoles
