#!/bin/bash -v
################################### lab16-create-a-bosh-release.sh
# do this lab on your Ubuntu Jumpbox and targets 'my-bosh'

# Stub Out a PostgresSQL Release
bosh init release my-postgres-release
cd my-postgres-release
tree

# Create a Job
bosh generate job my-pg-server
tree
cat jobs/my-pg-server/spec
cat jobs/my-pg-server/monit
cp ../templates/pgsql_ctl.erb jobs/my-pg-server/templates/pgsql_ctl.erb
cp ../templates/monit jobs/my-pg-server/monit
cp ../templates/spec jobs/my-pg-server/spec

# Create a Package
bosh generate package my-pg-pkg
tree
cp ../templates/my-pg-pkg-spec packages/my-pg-pkg/spec

curl -o postgresql-9.3.5.tar.gz https://ftp.postgresql.org/pub/source/v9.3.5/postgresql-9.3.5.tar.gz
mv postgresql-9.3.5.tar.gz src

cp ../templates/my-pg-pkg-packaging packages/my-pg-pkg/packaging
cp ../templates/final.yml config/final.yml

# Create, Upload and Deploy the Release

echo my-postgres | bosh create release --force

bosh upload release

printf 'admin\nadmin' | bosh target 10.193.$OCTET.244
export DIRECTOR_UUID=`bosh status | grep UUID | cut -c10-`

sed "s/\$OCTET/$OCTET/g; s/\$DIRECTOR_UUID/$DIRECTOR_UUID/g" ../templates/postgres.yml > postgres.yml

bosh deployment postgres.yml

echo yes | bosh deploy

if ! type psql >/dev/null; then
  echo $ENV_PWD | sudo -S apt-get install -y postgresql-client
fi

echo '\l' | psql -h 10.193.$OCTET.242 --username=vcap -d template1

cd ..
