#!/bin/bash -v
################################### lab15-deploying-with-bosh.sh
# do this lab on your Ubuntu Jumpbox and targets 'my-bosh'

git clone https://github.com/cloudfoundry-incubator/datadog-firehose-nozzle-release

cp -r datadog-firehose-nozzle-release datadog-firehose-nozzle-release-backup

# Create and Upload a Release

cd datadog-firehose-nozzle-release

bosh create release releases/datadog-firehose-nozzle/datadog-firehose-nozzle-12.yml --with-tarball

bosh releases

bosh upload release releases/datadog-firehose-nozzle/datadog-firehose-nozzle-12.tgz

bosh releases

# Download the stemcell

#bosh public stemcells

bosh download public stemcell bosh-stemcell-3262.9-vsphere-esxi-ubuntu-trusty-go_agent.tgz

bosh stemcells

bosh upload stemcell bosh-stemcell-3262.9-vsphere-esxi-ubuntu-trusty-go_agent.tgz

rm bosh-stemcell-3262.9-vsphere-esxi-ubuntu-trusty-go_agent.tgz

bosh stemcells

# Configure Access for the DataDog Nozzle

echo $ENV_PWD | sudo -S gem install cf-uaac

uaac target https://uaa.run.haas-$NN.pez.pivotal.io --skip-ssl-validation

uaac token client get admin -s $ADMIN_CLIENT_PWD

uaac client add datadog-firehose-user --scope 'openid,oauth.approvals,doppler.firehose' --authorized_grant_types 'authorization_code,client_credentials,refresh_token' --authorities 'oauth.login,doppler.firehose' --secret datadog-firehose-password

# Create the Deployment Manifest and Deploy

printf 'admin\nadmin' | bosh target 10.193.$OCTET.244
export DIRECTOR_UUID=`bosh status | grep UUID | cut -c10-`

# obtain PCF_DEPLOYMENT cf-instance from "p-bosh"
export BOSH="BUNDLE_GEMFILE=/home/tempest-web/tempest/web/vendor/bosh/Gemfile bundle exec bosh"

export PCF_DEPLOYMENT=`./sshpass -p $ENV_PWD ssh -oStrictHostKeyChecking=no ubuntu@opsmgr.haas-$NN.pez.pivotal.io "printf 'director\n$DIRECTOR_PWD' | $BOSH --ca-cert /var/tempest/workspaces/default/root_ca_certificate target 10.193.$OCTET.31 >/dev/null; $BOSH deployments | grep '|.*cf-.*|' | head -1 | cut -d'|' -f2"`

sed "s/\$OCTET/$OCTET/g; s/\$NN/$NN/g; s/\$DATADOG_API_KEY/$DATADOG_API_KEY/g; s/\$DIRECTOR_UUID/$DIRECTOR_UUID/g; s/\$PCF_DEPLOYMENT/$PCF_DEPLOYMENT/g" ../templates/datadog-firehose.yml > datadog-firehose.yml

bosh deployment datadog-firehose.yml

echo yes | bosh deploy

# Create Datadog Dashboard

cd ..

if ! type ./datadog-dashboard-gen >/dev/null; then
  curl -o datadog-dashboard-gen https://s3.amazonaws.com/pivotal-cloud-foundry-administrator/datadog-dashboard-gen
  chmod +x datadog-dashboard-gen
fi

./datadog-dashboard-gen -opsman_user=admin -opsman_password=$ENV_PWD -opsman_ip=opsmgr.haas-$NN.pez.pivotal.io -uaa_domain=opsmgr.haas-$NN.pez.pivotal.io/uaa -ddapikey=$DATADOG_API_KEY -ddappkey=$DATADOG_APP_KEY

# view Datadog Dashboard at https://app.datadoghq.com/
