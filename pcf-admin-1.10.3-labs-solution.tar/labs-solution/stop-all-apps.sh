#!/bin/bash -v

. ./set-env.sh

cf login -a api.run.haas-$NN.pez.pivotal.io -u admin -p $UAA_ADMIN_PWD -o $YOUR_INITIALS-org -s dev --skip-ssl-validation

cf stop articulate
cf stop articulate-new-bp
cf stop attendee-service
cf stop node-app
cf stop php-app
cf stop python-app
cf stop ruby-app
