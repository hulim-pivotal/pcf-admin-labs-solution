#!/bin/bash -v
################################### lab01-install-ops-manager.sh
# do this lab using vSphere Client and Ops Manager console
