#!/bin/bash 

# all variables can be obtained upon lab02 completion
# labNN: prefix indicates when the variable is first used

# lab03: provided by instructor
export INSTRUCTOR_NN=
export NN=
export OCTET=
export ENV_PWD=
export YOUR_INITIALS=
export YOUR_USERID=

# lab05: obtain from OpsMgr > Elastic Runtime tile > Credentials > UAA > Admin Credentials
export UAA_ADMIN_PWD=

# lab15: obtain from OpsMgr > Elastic Runtime tile > Credentials > UAA > Admin Client Credentials
export ADMIN_CLIENT_PWD=

# lab13: obtain from OpsMgr > Ops Mgr Director tile > Credentials > Ops Manager Director > Director Credentials
export DIRECTOR_PWD=

# lab15: obtain from your account at app.datadoghq.com > APIs
export DATADOG_API_KEY=
export DATADOG_APP_KEY=

# lab17: obtain from OpsMgr > MySQL tile > Status > MySQLServer index 0
export MYSQL_SERVER_IP=

# lab17: obtain from OpsMgr > MySQL tile > Credentials > MySQL Server > Mysql Admin Password
export MYSQL_ADMIN_PWD=
