#!/bin/bash -v
. ./set-env.sh

# do these labs manually using vSphere Client and Ops Manager console
./lab01-install-ops-manager.sh
./lab02-install-elastic-runtime-with-ops-manager.sh
# do these labs in instructor's PCF instance
./lab03-push-to-cloud.sh
./lab04-logging-scaling-ha.sh
./lab05-services.sh
### from here onwards do the labs in your own PCF instance
./lab06-orgs-spaces-roles.sh
### run manually when needed & cleanup after use, as it will impact subsequent labs
#./lab07-quotas.sh
#./lab07-quotas-cleanup.sh
./lab08-system-log-draining.sh
./lab09-monitoring.sh
./lab10-deploy-an-application.sh
### run manually when needed & cleanup after use, as it will impact subsequent labs
#./lab11-application-security-groups.sh
#./lab11-application-security-groups-cleanup.sh
### run manually when needed & cleanup after use, as it will impact subsequent labs
#./lab12-buildpack.sh
#./lab12-buildpack-cleanup.sh
./lab13-troubleshooting.sh
./lab14-deploy-bosh.sh
./lab15-deploying-with-bosh.sh
./lab16-create-a-bosh-release.sh
./lab17-backing-up-pcf.sh
### do these labs manually using vSphere Client and Ops Manager console
#./lab18-restoring-pcf.sh
#./lab19-upgrading-ops-manager.sh
#./lab20-upgrading-elastic-runtime.sh
