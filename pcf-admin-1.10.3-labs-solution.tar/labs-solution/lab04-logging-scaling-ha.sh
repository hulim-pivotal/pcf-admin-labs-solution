#!/bin/bash -v
################################### lab04-logging-scaling-ha.sh
# do this lab on your laptop or Ubuntu Jumpbox and target instructor's PCF instance

cf login -a api.run.haas-$INSTRUCTOR_NN.pez.pivotal.io -u $YOUR_USERID -p password --skip-ssl-validation

wget https://github.com/pivotal-education/pcf-articulate-code/releases/download/0.0.1/articulate-0.0.1-SNAPSHOT.jar

mkdir articulate
mv articulate-0.0.1-SNAPSHOT.jar articulate/
cd articulate/
cf push articulate -p ./articulate-0.0.1-SNAPSHOT.jar -m 768M -n articulate-$YOUR_INITIALS

### do the following steps manually to observe scaling behaviors
#cf logs articulate
#cf start articulate
#cf events articulate
#cf logs articulate | grep "API\|CELL"
#cf scale articulate -m 1G
#cf scale articulate -m 768M
#cf scale articulate -i 3
#cf app articulate
#cf events articulate
#cf scale articulate -i 1

cd ..
