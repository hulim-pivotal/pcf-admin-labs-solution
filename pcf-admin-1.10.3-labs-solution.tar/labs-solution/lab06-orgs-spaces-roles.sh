#!/bin/bash -v
################################### lab06-orgs-spaces-roles.sh
# do this lab on your Ubuntu Jumpbox and target your own PCF instance

cf login -a api.run.haas-$NN.pez.pivotal.io -u admin -p $UAA_ADMIN_PWD --skip-ssl-validation -o system -s system

cf create-org $YOUR_INITIALS-org
cf target -o $YOUR_INITIALS-org
cf create-space dev
cf target -s dev

cf create-user a.manager@pivotal.io password
cf set-org-role a.manager@pivotal.io $YOUR_INITIALS-org OrgManager
cf org-users $YOUR_INITIALS-org

cf space-users $YOUR_INITIALS-org dev
cf create-user a.developer@pivotal.io password
cf set-space-role a.developer@pivotal.io $YOUR_INITIALS-org dev SpaceDeveloper
cf space-users $YOUR_INITIALS-org dev
