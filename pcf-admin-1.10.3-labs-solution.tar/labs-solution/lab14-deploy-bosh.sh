#!/bin/bash -v
################################### lab14-deploy-bosh.sh
# do this lab on your Ubuntu Jumpbox and targets 'my-bosh'  

# Install bosh-init
if ! type bosh-init >/dev/null; then
  echo $ENV_PWD | sudo -S apt-get install -y build-essential zlibc zlib1g-dev ruby ruby-dev openssl libxslt-dev libxml2-dev libssl-dev libreadline6 libreadline6-dev libyaml-dev libsqlite3-dev sqlite3
  curl -o bosh-init https://s3.amazonaws.com/bosh-init-artifacts/bosh-init-0.0.96-linux-amd64
  chmod +x bosh-init
  echo $ENV_PWD | sudo -S mv bosh-init /usr/local/bin/
fi
bosh-init -v

# Deploy BOSH

mkdir my-bosh

sed "s/\$OCTET/$OCTET/g; s/\$NN/$NN/g; s/\$ENV_PWD/$ENV_PWD/g" templates/bosh.yml > my-bosh/bosh.yml

cd my-bosh

bosh-init deploy bosh.yml

# Install the BOSH CLI

if ! type bosh >/dev/null; then
  echo $ENV_PWD | sudo -S apt-get install build-essential ruby ruby-dev libxml2-dev libsqlite3-dev libxslt1-dev libpq-dev libmysqlclient-dev zlib1g-dev
  echo $ENV_PWD | sudo -S gem install bosh_cli --no-ri --no-rdoc
fi

# Explore your BOSH installation

printf 'admin\nadmin' | bosh target 10.193.$OCTET.244
bosh status
bosh deployments
# password for vcap: c1oudc0w
#ssh vcap@10.193.$OCTET.244
#echo c1oudc0w | sudo -S monit summary

cd ..
