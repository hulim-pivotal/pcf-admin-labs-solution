#!/bin/bash -v
################################### lab11-application-security-groups-cleanup.sh
# do this lab on your Ubuntu Jumpbox and target your own PCF instance

cf login -a api.run.haas-$NN.pez.pivotal.io -u admin -p $UAA_ADMIN_PWD -o $YOUR_INITIALS-org -s dev --skip-ssl-validation

cf bind-running-security-group default_security_group
