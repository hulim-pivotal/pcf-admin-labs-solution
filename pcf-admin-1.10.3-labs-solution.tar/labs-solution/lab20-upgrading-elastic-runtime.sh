#!/bin/bash -v
################################### lab20-upgrading-elastic-runtime
# do this lab using Ops Manager console

# Check System Health
#ssh ubuntu@opsmgr.haas-$NN.pez.pivotal.io
#bosh vms

# Upload New Tile Versions - using Ops Manager

# Deploy (Apply Changes) - using Ops Manager

# Validate Changes - test articulate application
