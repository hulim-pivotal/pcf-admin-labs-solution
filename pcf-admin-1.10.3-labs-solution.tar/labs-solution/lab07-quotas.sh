#!/bin/bash -v
################################### lab07-quotas.sh
# do this lab on your Ubuntu Jumpbox and target your own PCF instance

cf login -a api.run.haas-$NN.pez.pivotal.io -u admin -p $UAA_ADMIN_PWD -o system -s system --skip-ssl-validation

cf create-quota $YOUR_INITIALS-quota -m 2G -i 2G -r 2 -s 3 --allow-paid-service-plans
cf set-quota $YOUR_INITIALS-org $YOUR_INITIALS-quota

cf login -u a.manager@pivotal.io -p password -s dev
cf create-space staging
cf set-space-role a.developer@pivotal.io $YOUR_INITIALS-org staging SpaceDeveloper

cf login -u a.developer@pivotal.io -p password -s dev
cf create-service app-autoscaler standard a1
cf create-service app-autoscaler standard a2
@echo this will fail bcos org quota allows only 2 service instances
cf create-service app-autoscaler standard a3
cf target -s staging
@echo this will fail bcos org quota allows only 2 service instances
cf create-service app-autoscaler standard a1

cf target -s dev
cf delete-service a2 -f

cf login -u a.manager@pivotal.io -p password -s dev
cf create-space-quota $YOUR_INITIALS-space-quota -m 1G -i 1G -r 1 -s 1 --allow-paid-service-plans
cf set-space-quota dev $YOUR_INITIALS-space-quota
cf set-space-quota staging $YOUR_INITIALS-space-quota

cf org $YOUR_INITIALS-org
cf space dev
cf space staging

cf login -u a.developer@pivotal.io -p password -s dev
@echo this will fail bcos space quota allows only 1 service instance
cf create-service app-autoscaler standard a2
cf target -s staging
cf create-service app-autoscaler standard a1
