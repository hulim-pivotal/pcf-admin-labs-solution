#!/bin/bash -v
################################### lab17-backing-up-pcf.sh
# do this lab on your Ubuntu Jumpbox

# Install cfops

mkdir backups
cd backups
wget -O cfops https://github.com/pivotalservices/cfops/releases/download/v3.1.7/cfops_linux64
#curl -o cfops https://s3.amazonaws.com/pivotal-cloud-foundry-administrator/cfops
chmod +x cfops
./cfops list-tiles
./cfops help backup

# Backup Ops Manager

LOG_LEVEL=debug ./cfops backup --opsmanagerhost opsmgr.haas-$NN.pez.pivotal.io --adminuser admin --adminpass $ENV_PWD --opsmanageruser ubuntu --opsmanagerpass $ENV_PWD --opsmanagerpassphrase $ENV_PWD --tile ops-manager --destination ./

ls opsmanager
head opsmanager/installation.json
# vim opsmanager/deployments.tar.gz
# vim opsmanager/installation.zip

# Backup the Pivotal Elastic Runtim

LOG_LEVEL=debug ./cfops backup --opsmanagerhost opsmgr.haas-$NN.pez.pivotal.io --adminuser admin --adminpass $ENV_PWD --opsmanageruser ubuntu --opsmanagerpass $ENV_PWD --opsmanagerpassphrase $ENV_PWD --tile elastic-runtime --destination ./

ls opsmanager
ls *.backup
head mysql.backup
tar -tf nfs_server.backup | head

# Backup the MySQL Tile

if ! type mysqldump >/dev/null; then
  echo $ENV_PWD | sudo -S apt-get -y install mysql-client
fi

mysqldump -u admin -p$MYSQL_ADMIN_PWD -h $MYSQL_SERVER_IP --all-databases > mysql-tile.sql
grep attendee mysql-tile.sql
