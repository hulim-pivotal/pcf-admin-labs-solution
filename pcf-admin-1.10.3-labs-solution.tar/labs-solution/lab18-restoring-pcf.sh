#!/bin/bash -v
################################### lab18-restoring-pcf.sh
# do this lab on your Ubuntu Jumpbox

# Review the State of your PCF

cf login -a api.run.haas-$NN.pez.pivotal.io -u admin -p $UAA_ADMIN_PWD -o $YOUR_INITIALS-org -s dev --skip-ssl-validation
cf orgs
cf spaces
cf org-users $YOUR_INITIALS-org
cf space-users $YOUR_INITIALS-org dev
cf apps
cf services

# Delete your PCF Installation - using OpsMgr

# Deploy the OpsMgr VM - using vSphere Client

# Restore OpsMgr

#cd backups

#LOG_LEVEL=debug ./cfops restore --opsmanagerhost opsmgr.haas-$NN.pez.pivotal.io --adminuser admin --adminpass $ENV_PWD --opsmanageruser ubuntu --opsmanagerpass $ENV_PWD --opsmanagerpassphrase $ENV_PWD --tile ops-manager --destination ./

#ssh ubuntu@opsmgr.haas-[NN].pez.pivotal.io
#sudo mv /var/tempest/workspaces/default/deployments/bosh-state.json /var/tempest/workspaces/default/deployments/bosh-state.json.old

# Deploy - using OpsMgr

# Restore MySQL

#mysql -u admin -p$MYSQL_ADMIN_PWD -h $MYSQL_SERVER_IP -e "set global enforce_storage_engine=NULL;"
#mysql -u admin -p$MYSQL_ADMIN_PWD -h $MYSQL_SERVER_IP < mysql-tile.sql
#mysql -u admin -p$MYSQL_ADMIN_PWD -h $MYSQL_SERVER_IP -e "FLUSH PRIVILEGES"
#mysql -u admin -p$MYSQL_ADMIN_PWD -h $MYSQL_SERVER_IP -e "set global enforce_storage_engine='InnoDB';"

# Restore the Pivotal Elastic Runtime

#LOG_LEVEL=debug ./cfops restore --opsmanagerhost opsmgr.haas-$NN.pez.pivotal.io --adminuser admin --adminpass $ENV_PWD --opsmanageruser ubuntu --opsmanagerpass $ENV_PWD --opsmanagerpassphrase $ENV_PWD --tile elastic-runtime --destination ./
