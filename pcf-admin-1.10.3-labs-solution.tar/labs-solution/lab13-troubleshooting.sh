#!/bin/bash -v
################################### lab13-troubleshooting.sh
# do this lab using vSphere Client and 'ssh ubuntu@opsmgr.haas-[NN].pez.pivotal.io' and targets 'p-bosh'
