#!/bin/bash -v
################################### lab09-monitoring.sh
# do this lab using Ops Manager, VisualVM and Datadog consoles
