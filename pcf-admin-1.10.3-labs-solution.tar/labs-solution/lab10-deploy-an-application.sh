#!/bin/bash -v
################################### lab10-deploy-an-application.sh
# do this lab on your Ubuntu Jumpbox and target your own PCF instance

cf login -a api.run.haas-$NN.pez.pivotal.io -u admin -p $UAA_ADMIN_PWD -o $YOUR_INITIALS-org -s dev --skip-ssl-validation

if [ ! -d articulate ]; then
  wget https://github.com/pivotal-education/pcf-articulate-code/releases/download/0.0.1/articulate-0.0.1-SNAPSHOT.jar
  mkdir articulate
  mv articulate-0.0.1-SNAPSHOT.jar articulate/
fi

cd articulate
cf push articulate -p ./articulate-0.0.1-SNAPSHOT.jar -m 768M -n articulate
cd ..

if [ ! -d attendee-service ]; then
  wget https://github.com/pivotal-education/pcf-attendee-service-code/releases/download/0.0.1/attendee-service-0.0.1-SNAPSHOT.jar
  mkdir attendee-service
  mv attendee-service-0.0.1-SNAPSHOT.jar attendee-service/
fi

cd attendee-service
cf push attendee-service -p ./attendee-service-0.0.1-SNAPSHOT.jar -m 512M -n attendee-service --no-start
cf create-service p-mysql 100mb attendee-mysql
cf bind-service attendee-service attendee-mysql
cf restart attendee-service

curl http://attendee-service.cfapps.haas-$NN.pez.pivotal.io

# instructor will get error 'service instance name is taken: attendee-service' during 'create-user-provided-service'
# but not students, bcos instructor performed this step twice on same PCF. You can ignore the error.

cf create-user-provided-service attendee-service -p uri <<< http://attendee-service.cfapps.haas-$NN.pez.pivotal.io/attendees
cf bind-service articulate attendee-service
cf restart articulate
cf env articulate
cd ..
