This labs-solution serves the following objectives:

- to complement lab materials with minimal deviation from it
- to define & re-use env specific variables (. ./set-env.sh)
- to allow instructor to setup most of the labs for demo/reference on one command  (run-all-labs.sh)
- to generate YML/JSON/etc using parameterised templates & 'sed' commands to avoid typo errors
- to allow students to deploy "articulate" apps (again) to own PCF instance without wasting time (lab10)
- to allow students who cannot complete labs to run the solution for that lab (labNN-xxx.sh)
- to serve as simplified & cloneable lab instructions for students
- to automate commands that require prompts e.g. sudo, ssh, bosh target
- do not perform UI/interactive tasks e.g. vSphere/OpsMgr/Datadog console tasks, but provide reminder comments in scripts

Deviations from lab instructions:

- space 'development' is renamed to 'dev' on instructor's PCF instance s.t. instructor can run all labs without switching spaces
- random-route is replaced with student's initials as suffix e.g. cf push ... -n articulate-$YOUR_INITIALS

NOTE: always remember to initialise env variables in a new terminal session by calling ". ./set-env.sh"
