#!/bin/bash -v
################################### lab12-buildpack.sh
# do this lab on your Ubuntu Jumpbox and target your own PCF instance

cf login -a api.run.haas-$NN.pez.pivotal.io -u admin -p $UAA_ADMIN_PWD -o $YOUR_INITIALS-org -s dev --skip-ssl-validation

# how to use a custom buildpack
cd articulate
cf app articulate | grep buildpack
cf push articulate -p ./articulate-0.0.1-SNAPSHOT.jar -m 768M -b https://github.com/cloudfoundry/java-buildpack.git
cf app articulate | grep buildpack
curl http://articulate.cfapps.haas-$NN.pez.pivotal.io |grep "Java Version"

# how to configure the Java Buildpack
cf set-env articulate JBP_CONFIG_OPEN_JDK_JRE "{jre: { version: 1.8.0_121 }}"
cf restage articulate
curl http://articulate.cfapps.haas-$NN.pez.pivotal.io |grep "Java Version"

# How to create custom buildpack available across your PCF installation
wget https://github.com/cloudfoundry/java-buildpack/releases/download/v3.15/java-buildpack-v3.15.zip
cf create-buildpack super_awesome_java_pack ./java-buildpack-v3.15.zip 1
cf buildpacks
cd articulate
cf push articulate-new-bp -m 768M -p ./articulate-0.0.1-SNAPSHOT.jar
cf app articulate-new-bp | grep buildpack
cd ..
