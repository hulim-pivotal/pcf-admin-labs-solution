#!/bin/bash -v
################################### lab12-buildpack-cleanup.sh
# do this lab on your Ubuntu Jumpbox and target your own PCF instance

cf login -a api.run.haas-$NN.pez.pivotal.io -u admin -p $UAA_ADMIN_PWD -o $YOUR_INITIALS-org -s dev --skip-ssl-validation

cf delete-buildpack super_awesome_java_pack -f

cf delete articulate-new-bp -f
