#!/bin/bash -v
################################### lab19-upgrading-ops-manager.sh
# do this lab on your Ubuntu Jumpbox

# Check System Health
#ssh ubuntu@opsmgr.haas-$NN.pez.pivotal.io
#bosh vms

# Backup/Export Installation Settings

mkdir backups-upgrade
cd backups-upgrade
wget -O cfops https://github.com/pivotalservices/cfops/releases/download/v3.1.7/cfops_linux64
#curl -o cfops https://s3.amazonaws.com/pivotal-cloud-foundry-administrator/cfops
chmod +x cfops

#LOG_LEVEL=debug ./cfops backup --opsmanagerhost opsmgr.haas-$NN.pez.pivotal.io --adminuser admin --adminpass $ENV_PWD --opsmanageruser ubuntu --opsmanagerpass $ENV_PWD --opsmanagerpassphrase $ENV_PWD --tile ops-manager --destination ./

# Deploy the New Version of Ops Manager - using vSphere Client

# Restore Ops Manager

#LOG_LEVEL=debug ./cfops restore --opsmanagerhost opsmgr.haas-$NN.pez.pivotal.io --adminuser admin --adminpass $ENV_PWD --opsmanageruser ubuntu --opsmanagerpass $ENV_PWD --opsmanagerpassphrase $ENV_PWD --tile ops-manager --destination ./

# Apply Changes - using Ops Manager
